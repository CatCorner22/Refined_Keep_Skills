# llm-qc-suite

A Claude plugin that bundles one skill, eight red-team subagents, two commands, and two scanners.

## Contents

| Path | Purpose |
|---|---|
| `.claude-plugin/plugin.json` | Plugin manifest |
| `skills/llm-quality-control/SKILL.md` | Main workflow, precedence, and output format |
| `skills/llm-quality-control/references/quality-control.md` | Verification checklists |
| `skills/llm-quality-control/references/red-team-swarm.md` | Swarm tiers, lenses, Defender rules D1-D15, report |
| `skills/llm-quality-control/references/one-way-optimal-language.md` | The complete original writing skill, byte for byte |
| `skills/llm-quality-control/references/original-plugin.json` | The original plugin manifest, byte for byte |
| `skills/llm-quality-control/scripts/av_scan.py` | Fallback active-voice scanner |
| `skills/llm-quality-control/scripts/watchlist_scan.py` | Watchlist, spacing, abbreviation, and length scanner |
| `agents/rt-*.md` | Red-team subagents A1-A6, Arbiter, Defender |
| `commands/qc-review.md`, `commands/red-team.md` | Slash commands |
| `tools/validate_package.py` | Package integrity check |

## Install

- **Claude Code plugin:** unzip, then run `claude --plugin-dir ./llm-qc-suite`, or add the folder to a local marketplace. Use `/llm-qc-suite:qc-review FILE` and `/llm-qc-suite:red-team FILE`.
- **Skill only (Claude.ai or API):** zip or upload the `skills/llm-quality-control` folder. Without subagents, the skill runs each red-team charter as a separate sequential pass.

## Check the package

    python3 tools/validate_package.py

## Known limits

- This package omits the full `active_voice_check.py` that the original skill describes. The bundled scanner uses the original skill's fallback patterns and adds a command-line wrapper. It flags more than it needs to, and the eye check stays mandatory.
- The original skill's legal statements, research figures, and benchmark results are source claims. This package does not re-verify them. Its own "last checked" date is 9 November 2026.
- A single model that simulates every red-team role shares its own blind spots.
- The Defender calibration thresholds in D13 (more than half defeated; none across ten or more) are judgment calls. Tune them after real runs.
