#!/usr/bin/env python3
"""Validate the llm-qc-suite package: manifest, front matter, links, tag balance, and verbatim references."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILL = ROOT / "skills" / "llm-quality-control"
errors = []


def check(condition, message):
    if not condition:
        errors.append(message)


def front_matter(path):
    text = path.read_text(encoding="utf-8")
    match = re.match(r"---\n(.*?)\n---\n", text, re.S)
    if not match:
        return None
    return dict(re.findall(r"^([A-Za-z-]+):\s*(.+)$", match.group(1), re.M))


manifest = json.loads((ROOT / ".claude-plugin" / "plugin.json").read_text(encoding="utf-8"))
for key in ("name", "version", "description"):
    check(key in manifest, f"plugin.json lacks {key}")

meta = front_matter(SKILL / "SKILL.md")
check(meta is not None, "SKILL.md lacks front matter")
if meta:
    check(meta.get("name") == "llm-quality-control", "skill name mismatch")
    check(len(meta.get("description", "")) <= 1024, "skill description exceeds 1024 characters")

for agent in sorted((ROOT / "agents").glob("*.md")):
    data = front_matter(agent)
    check(data is not None, f"{agent.name} lacks front matter")
    if data:
        check(data.get("name") == agent.stem, f"{agent.name}: name differs from file name")
        for key in ("description", "tools"):
            check(key in data, f"{agent.name} lacks {key}")
        check("Write" not in data.get("tools", "") and "Edit" not in data.get("tools", ""),
              f"{agent.name}: agents must stay read-only")

for command in sorted((ROOT / "commands").glob("*.md")):
    data = front_matter(command)
    check(data is not None and "description" in data, f"{command.name} lacks a description")

text = (SKILL / "SKILL.md").read_text(encoding="utf-8")
for ref in set(re.findall(r"`((?:references|scripts)/[^`\s]+)`", text)):
    check((SKILL / ref).exists(), f"SKILL.md links to missing {ref}")

original = (SKILL / "references" / "one-way-optimal-language.md").read_text(encoding="utf-8")
for marker in ("H1 Keep the meaning", "R30 One rule, one place", "## Verification", "Known contradictions"):
    check(marker in original, f"original skill lacks '{marker}'")
check(len(original.encode("utf-8")) == 64242, "original skill size changed (expected 64242 bytes)")
check((SKILL / "references" / "original-plugin.json").stat().st_size == 438, "original plugin.json size changed")
json.loads((SKILL / "references" / "original-plugin.json").read_text(encoding="utf-8"))

rt = (SKILL / "references" / "red-team-swarm.md").read_text(encoding="utf-8")
for number in range(1, 16):
    check(re.search(rf"\*\*D{number} ", rt), f"Defender rule D{number} missing")
for number in range(1, 15):
    check(re.search(rf"\*\*L{number} ", rt), f"lens L{number} missing")
for agent in re.findall(r"`(rt-[a-z-]+)`", rt):
    check((ROOT / "agents" / f"{agent}.md").exists(), f"agent {agent} missing")

for script in (SKILL / "scripts").glob("*.py"):
    try:
        compile(script.read_text(encoding="utf-8"), str(script), "exec")
    except SyntaxError as error:
        errors.append(f"{script.name}: {error}")

if errors:
    print("FAIL")
    for error in errors:
        print(" -", error)
    sys.exit(1)
print("OK: package checks passed")
