---
description: Run the adversarial red-team swarm (present defects and future design problems) on a file, folder, or plan
argument-hint: [file-or-folder] [optional: tier T1|T2|T3]
---

Use the `llm-quality-control` skill and its `references/red-team-swarm.md` to red-team `$ARGUMENTS`.

1. Choose the tier (T1, T2, or T3) from the stakes unless the arguments name one. State the tier and the reason.
2. Launch the matching `rt-*` subagents as separate agents so that each works independently: `rt-proofreader`, `rt-style-prosecutor`, `rt-fact-auditor`, `rt-break-it-tester`, `rt-future-analyst`, `rt-gap-analyst`. Give each agent only the artifact, the requirements, and its charter.
3. Send all findings to `rt-arbiter`. At T3, run cross-examination, then send each Critical, High, and contested finding to `rt-defender`, collect one finder rebuttal, and ask `rt-arbiter` to rule.
4. Produce the report in the skill's format. Never edit the artifact. Never declare it ready. If you cannot launch subagents, run each charter as a separate sequential pass and say in Flags that one model simulated the swarm.
