---
description: Run the full quality-control workflow (plan, verify, writing standard, checks, red team) on a file, folder, or pasted deliverable
argument-hint: [file-or-folder] [optional: tier T1|T2|T3]
---

Use the `llm-quality-control` skill to review `$ARGUMENTS`.

1. Read the skill's `SKILL.md` and `references/one-way-optimal-language.md`.
2. Show the plan (Steps 1-3) before you rewrite anything. If no one can answer questions, deliver the plan and the revision together and mark open choices `[X#]`.
3. Complete Steps 4-7 and deliver the output format in the skill.
4. Choose the red-team tier from the stakes unless the arguments name one. State the tier and the reason.

Report only checks that you ran.
