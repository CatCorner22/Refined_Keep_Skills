#!/usr/bin/env python3
"""Fallback active-voice scanner.

The pattern set comes verbatim from the one-way-optimal-language skill (fallback scan).
This wrapper adds a command line, Markdown handling, and verbatim/mention markers.
It flags more than it needs to, on purpose. Decide each hit with the skill's
Active Voice Step 2 (Decide). An eye check stays mandatory: no scanner catches
every reduced clause, heading fragment, or question.

Usage:  python3 av_scan.py [--strict] [--include-code] FILE [FILE ...]
Exit:   1 when any blocking hit remains, otherwise 0.
Marker: <!-- av:verbatim --> ... <!-- /av:verbatim -->  (legally required text)
        <!-- av:mention -->  ... <!-- /av:mention -->   (deliberate "before" examples)
"""
import argparse
import re
import sys

P = (r"(?:\w{2,}ed|cut|put|set|read|hit|shut|hurt|spread|cast|shed|upset|run|overcome|done|given|taken|"
     r"mistaken|shaken|made|seen|written|known|shown|grown|thrown|blown|drawn|withdrawn|sworn|torn|worn|"
     r"born|found|told|held|withheld|kept|left|built|brought|bought|caught|taught|thought|sought|sent|"
     r"spent|meant|dealt|felt|led|misled|fed|bred|lit|met|paid|laid|said|sold|driven|hidden|broken|"
     r"chosen|frozen|spoken|stolen|forgotten|begun|struck|stuck|understood|beaten|bitten|eaten|forbidden|"
     r"ridden|proven|swollen|bound|lost|shot|heard|dug|hung|won)")
NOT = r"(?!(?:need|bed|red|seed|feed|speed|bleed|breed|proceed|exceed|succeed|hundred|sacred|naked|wicked)\b)"
ADV = r"(?:\s+(?:\w+ly|not|n't|also|only|then|often|usually|always|never|already|still|just|all|last|first|now|again|been|being|be))*"
DET = r"(?:the|a|an|your|my|his|her|its|our|their|this|that|these|those|each|every|any)"
PATTERNS = [
    ("be/get/stay + participle", rf"\b(?:am|is|are|was|were|be|been|being|'s|'re|isn't|aren't|wasn't|weren't|get|gets|got|gotten|getting|remains?|remained|stays?|stayed|seems?|seemed|looks?|looked|feels?|felt|appears?|appeared|becomes?|became){ADV}\s+{NOT}{P}\b"),
    ("question: be ... participle", rf"(?:^|[.?!]\s+)(?:(?:what|where|how|why|which|who|when)\s+)?(?:is|are|was|were|isn't|aren't|wasn't|weren't)\s+(?:\w+\s+){{1,4}}?{NOT}{P}\b[^.]*\?"),
    ("have/get/keep + object + participle", rf"\b(?:have|has|had|having|get|gets|got|keep|keeps|kept|leave|want|wants|need|needs|make|makes|find)\s+{DET}\s+(?:\w+\s+){{1,2}}?{NOT}{P}\b"),
    ("elliptical: if/when/as/once + participle", rf"\b(?:if|when|once|unless|until|as|while|although|though|where|than)(?:\s+(?:\w+ly|not|otherwise))*\s+{NOT}{P}\b"),
    ("sentence-initial participle", rf"(?:^|[.;:!?]\s+|,\s+)(?:not\s+(?:to\s+be\s+)?)?{NOT}{P}\b(?=\s*(?:,|\b(?:by|for|in|on|with|to|at|after|before|from|under|during)\b))"),
    ("need + -ing", r"\b(?:need|needs|needed|want|wants|require|requires)\s+(?!(?:nothing|something|anything|everything|bedding|clothing|counseling|training|nursing|screening)\b)\w{2,}ing\b"),
    ("noun + participle + by/prep", rf"\b(?!(?:i|you|we|he|she|it|they|who|which|that|the|a|an|to|and|or|have|has|had|be|is|are|was|were)\b)\w+\s+(?:not\s+)?{NOT}{P}\s+(?:by|in|on|at|after|before|for|from|with|during|under|into|through|late|early)\b"),
    ("thing + participle", rf"\b(?:anything|something|everything|nothing)\s+{NOT}{P}\b"),
    ("participle at end after object", rf"\b{DET}\s+\w+\s+{NOT}{P}\s*[.,;:)]"),
]
COMPILED = [(name, re.compile(p, re.I)) for name, p in PATTERNS]



def scan(text):
    text = text.replace("\u2019", "'").replace("*", " ").replace("`", " ")
    return [(name, m.group(0).strip()) for name, rx in COMPILED for m in rx.finditer(text)]


MARK = re.compile(r"<!--\s*(/?)av:(verbatim|mention)\s*-->")
FENCE = re.compile(r"^\s*(```|~~~)")


def classify(path, include_code):
    """Yield (line_number, line_text, zone) where zone is TEXT, VERBATIM, or MENTION."""
    zone, in_fence, in_front = "TEXT", False, False
    with open(path, encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            if number == 1 and line.strip() == "---":
                in_front = True
                continue
            if in_front:
                in_front = line.strip() != "---"
                continue
            marker = MARK.search(line)
            if marker:
                zone = "TEXT" if marker.group(1) else marker.group(2).upper()
                continue
            if FENCE.match(line) and not include_code:
                in_fence = not in_fence
                continue
            if in_fence:
                continue
            yield number, line, zone


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("files", nargs="+")
    parser.add_argument("--strict", action="store_true",
                        help="count MENTION zones as blocking hits")
    parser.add_argument("--include-code", action="store_true",
                        help="scan fenced code blocks and front matter-free text alike")
    args = parser.parse_args(argv)
    blocking = verbatim = 0
    for path in args.files:
        for number, line, zone in classify(path, args.include_code):
            for name, fragment in scan(line):
                label = {"TEXT": "HIT", "VERBATIM": "VERBATIM", "MENTION": "MENTION"}[zone]
                print(f"{path}:{number}: [{label}:{name}] {fragment}")
                if zone == "TEXT" or (zone == "MENTION" and args.strict):
                    blocking += 1
                elif zone == "VERBATIM":
                    verbatim += 1
    print(f"blocking={blocking} verbatim={verbatim}", file=sys.stderr)
    return 1 if blocking else 0


if __name__ == "__main__":
    sys.exit(main())
