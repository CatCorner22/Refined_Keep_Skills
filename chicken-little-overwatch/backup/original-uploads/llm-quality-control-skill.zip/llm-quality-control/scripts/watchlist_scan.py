#!/usr/bin/env python3
"""Watchlist scanner for the one-way-optimal-language rules.

Searches for words and patterns that the skill tells the reviewer to inspect:
banned or risky modal verbs, vague time words, ambiguity triggers (R1-R30),
look-alike medical words (R5), Joint Commission "Do Not Use" items (R6),
dose-format errors (R14), one-space sentence endings (Typography), and long
sentences (S5). Every hit is a prompt to decide, not a verdict.

Usage:  python3 watchlist_scan.py [--limit N] [--no-length] FILE [FILE ...]
Exit:   0 always (the scan informs; the reviewer decides). Use --fail to exit 1 on hits.
"""
import argparse
import re
import sys

WORDS = {
    "R1/lexicon": r"shall|should|consider|can|cannot|need to|needs to|is to|agrees to|is required to|is responsible for|will be expected to",
    "R9 and/or": r"and/or",
    "R28 slash": r"\b[A-Za-z]+/[A-Za-z]+\b",
    "R13 time": r"within|upon|until|by\s+(?:the\s+)?(?:end|close|date)|between|business day|periodically|daily|twice a day|at least",
    "R16 exceptions": r"provided that|notwithstanding|subject to|may\b[^.]{0,40}\bonly\b",
    "R7/R18 references": r"herein|said|such|the foregoing|the same|above|below",
    "R15 examples": r"such as|e\.g\.|i\.e\.|etc\.|including",
    "R21 respectively": r"respectively",
    "R27 earlier/later": r"whichever",
    "R10/R24 quantifiers": r"\bany\b|\beach\b|\ball\b|\bevery\b",
    "R12 negation": r"unless|not\s+\w+\s+unless|cannot|never|no\s+longer",
    "R25 notice": r"notice|notify",
    "R26 may require": r"may require|may ask",
    "Vague standard": r"sole discretion|satisfactory|acceptable to|good faith|best efforts|reasonable|appropriate|adequate|as clinically indicated|promptly|immediately|as soon as possible|right away|timely|regularly|frequently|significant|substantial|material|soon|normal|usual|as needed|as directed|PRN|mild|moderate|severe|very|extremely",
    "Please": r"please",
    "R17 possibility": r"likely|unlikely|rare|common|very common",
}
LOOKALIKES = r"negative|positive|unremarkable|impressive|progressing|stable|occult|NPO|febrile|acute|chronic|discharge|culture|tolerate|compliance"
DO_NOT_USE = [
    ("R6 Do Not Use: U/IU after a number", r"\b\d+(?:\.\d+)?\s?(?:U|IU)\b"),
    ("R6 Do Not Use: QD/QOD", r"\b(?:Q\.D\.|QD|Q\.O\.D\.|QOD)\b"),
    ("R6 Do Not Use: MS/MSO4/MgSO4", r"\b(?:MS|MSO4|MgSO4)\b"),
    ("R14 trailing zero", r"\b\d+\.0\s?(?:mg|mcg|g|mL|units?)\b"),
    ("R14 missing leading zero", r"(?<![\d.])\.\d+\s?(?:mg|mcg|g|mL|units?)\b"),
]
ABBREVIATIONS = {"dr", "mr", "mrs", "ms", "prof", "st", "vs", "no", "u.s", "e.g", "i.e", "etc", "inc", "jr", "sr"}
ONE_SPACE = re.compile(r"(\S*)[.?!][\"\u201d\u2019)]? (?=[\"\u201c\u2018(]?[A-Z0-9])")
SENTENCE = re.compile(r"(?<=[.?!])\s+(?=[A-Z0-9\"\u201c(])")
FENCE = re.compile(r"^\s*(```|~~~)")


def lines_of(path):
    in_fence, in_front = False, False
    with open(path, encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            if number == 1 and line.strip() == "---":
                in_front = True
                continue
            if in_front:
                in_front = line.strip() != "---"
                continue
            if FENCE.match(line):
                in_fence = not in_fence
                continue
            if not in_fence and not line.lstrip().startswith(("<!--", "|---")):
                yield number, line.rstrip("\n")


def scan_file(path, limit, check_length):
    hits = []
    word_rx = [(label, re.compile(rf"\b(?:{pattern})\b" if label not in ("R9 and/or", "R28 slash", "R16 exceptions") else pattern, re.I))
               for label, pattern in WORDS.items()]
    look_rx = re.compile(rf"\b(?:{LOOKALIKES})\b", re.I)
    dnu = [(label, re.compile(pattern)) for label, pattern in DO_NOT_USE]
    for number, raw in lines_of(path):
        text = re.sub(r"[*_`]", "", raw)
        for label, rx in word_rx:
            for match in rx.finditer(text):
                hits.append((number, label, match.group(0)))
        for match in look_rx.finditer(text):
            hits.append((number, "R5 look-alike word", match.group(0)))
        for label, rx in dnu:
            for match in rx.finditer(text):
                hits.append((number, label, match.group(0)))
        for match in ONE_SPACE.finditer(text):
            if match.group(1).lower().strip("\"\u201c(") in ABBREVIATIONS:
                continue
            context = text[max(0, match.start() - 12): match.end() + 6]
            hits.append((number, "Typography: one space after sentence", context.strip()))
        if check_length:
            for sentence in SENTENCE.split(text):
                words = len(re.findall(r"[A-Za-z0-9'\u2019-]+", sentence))
                if words > limit:
                    hits.append((number, f"S5 length {words} > {limit}", sentence[:60] + "..."))
    return sorted(hits)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("files", nargs="+")
    parser.add_argument("--limit", type=int, default=25, help="sentence word limit (S5); use 15 for patient instructions")
    parser.add_argument("--no-length", action="store_true", help="skip the sentence-length check")
    parser.add_argument("--fail", action="store_true", help="exit 1 when any hit appears")
    args = parser.parse_args(argv)
    total = 0
    for path in args.files:
        for number, label, fragment in scan_file(path, args.limit, not args.no_length):
            print(f"{path}:{number}: [{label}] {fragment}")
            total += 1
    print(f"hits={total}", file=sys.stderr)
    return 1 if (args.fail and total) else 0


if __name__ == "__main__":
    sys.exit(main())
